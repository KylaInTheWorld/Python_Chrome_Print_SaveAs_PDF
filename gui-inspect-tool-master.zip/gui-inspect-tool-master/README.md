Collection of gui inspect tool for Windows.
* AccEvent.exe
* AccExplorer32.exe
* Inspect.exe
* SPYXX.EXE
* swapy-ob-0.4.3.exe
* UISpy.exe
* ViewWizard.exe
* WSEdit.EXE
